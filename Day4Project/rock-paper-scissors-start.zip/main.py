rock = '''
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = '''
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
'''

scissors = '''
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
'''

#Write your code below this line 👇
import random
print("Welcome to Rock, Paper, Scissors!")
name_images = ["Rock", "Paper", "Scissors"]
game_images = [rock, paper, scissors]
play_game = True

while play_game:
  try:
    player_choice = int(input("What do you choose? Type 0 for Rock, 1 for Paper, or 2 for Scissors.\n"))
  
    if player_choice >= 0 and player_choice <= 2:
      print("User chose:")
      print(name_images[player_choice]+"\n")
      print(game_images[player_choice])
      
      print("\nComputer chose:")
      computer_choice = random.randint(0, 2)
      print(name_images[computer_choice]+"\n")
      print(game_images[computer_choice])
      
      if player_choice == computer_choice:
        print("\nIt's a draw!")
      elif player_choice == 0 and computer_choice == 2:
        print("\nYou win!")
      elif player_choice == 1 and computer_choice == 0:
        print("\nYou win!")
      elif player_choice == 2 and computer_choice == 1:
        print("\nYou win!")
      else:
        print("\nYou lose!")
  
      play_again = input("\nWould you like to play again? Type any character different of 'n' for yes.\n").lower()
      
      if play_again == 'n':
        play_game = False
        print("\nThanks for playing!")        
  
  except ValueError:
    print("You must enter a number between 0 and 2.") 
    print("Please try again.")
   
  
  
  


